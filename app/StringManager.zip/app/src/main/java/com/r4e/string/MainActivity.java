package com.r4e.string;

import com.r4e.string.SplActivity;
import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bachors.wordtospan.*;
import com.google.android.material.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import androidx.core.widget.NestedScrollView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainActivity extends AppCompatActivity {
	
	private String string = "";
	private String string2 = "";
	private String strings = "";
	
	private NestedScrollView nested;
	private LinearLayout bg;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView textview1;
	private ImageView imageview1;
	private ImageView imageview2;
	private ImageView imageview4;
	private ImageView imageview3;
	private TextView textview2;
	private TextView textview3;
	
	private AlertDialog.Builder dlg;
	private AlertDialog.Builder Dialog;
	private Intent jintr = new Intent();
	private AlertDialog.Builder exj;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		nested = findViewById(R.id.nested);
		bg = findViewById(R.id.bg);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		textview1 = findViewById(R.id.textview1);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		imageview4 = findViewById(R.id.imageview4);
		imageview3 = findViewById(R.id.imageview3);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		dlg = new AlertDialog.Builder(this);
		Dialog = new AlertDialog.Builder(this);
		exj = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog BottomsheetD = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
				View BottomsheetV;
				BottomsheetV = getLayoutInflater().inflate(R.layout.bottomsh,null );
				BottomsheetD.setContentView(BottomsheetV);
				final EditText key = (EditText) BottomsheetV.findViewById(R.id.key);
				final EditText values = (EditText) BottomsheetV.findViewById(R.id.values);
				final com.google.android.material.textfield.TextInputLayout textinput1 = (com.google.android.material.textfield.TextInputLayout) BottomsheetV.findViewById(R.id.textinput1);
				final com.google.android.material.textfield.TextInputLayout textinput2 = (com.google.android.material.textfield.TextInputLayout) BottomsheetV.findViewById(R.id.textinput2);
				final com.google.android.material.button.MaterialButton ok = (com.google.android.material.button.MaterialButton) BottomsheetV.findViewById(R.id.ok);
				BottomsheetD.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				BottomsheetD.show();
				ok.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						BottomsheetD.dismiss();
						if (key.getText().toString().equals("") || values.getText().toString().equals("")) {
							textinput1.setError("Key Cannot Empty");
							textinput2.setError("Values Cannot Empty");
						}
						else {
							_spannableTextview(textview2, "#B6BCD3", "#B6BCD3", "#039BE5", "#29B6F6", "#EF5350", false, textview2.getText().toString().concat("\n<string name=\"".concat(key.getText().toString().concat("\">".concat(values.getText().toString().concat("</string>"))))));
							_spannableTextview(textview3, "#B6BCD3", "#B6BCD3", "#039BE5", "#29B6F6", "#EF5350", false, "</resources>");
						}
					}
				});
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview2.getText().toString().concat("\n".concat(textview3.getText().toString()))));
				_SnackBar(bg, "copied", "");
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MaterialAlertDialogBuilder exj = new MaterialAlertDialogBuilder(MainActivity.this);
				exj.setTitle("Save File Confirmation");
				exj.setMessage("Save The File? It Will Save In Folder /StringBuilder/");
				exj.setPositiveButton("Save", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/StringBuilder/".concat("strings.xml")), textview2.getText().toString().concat("\n".concat(textview3.getText().toString())));
						_SnackBar(bg, "Saved To /StringBuilder/strings.xml", "");
					}
				});
				exj.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				exj.create().show();
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MaterialAlertDialogBuilder Dialog = new MaterialAlertDialogBuilder(MainActivity.this);
				Dialog.setTitle("About String Builder ");
				Dialog.setMessage("String Builder Made To Help You Create String.xml For Your App.\n\n\nApp Made By R4E Studio\nhttps://github.com/rinxyzz\nhttps://rin4ever.xyz");
				Dialog.setPositiveButton("OPEN SOURCE LICENSE", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						MaterialAlertDialogBuilder dlg = new MaterialAlertDialogBuilder(MainActivity.this);
						dlg.setTitle("Open Source License");
						dlg.setMessage("- Material M3\n Apache-2.0 license - m3.material.io\n\n- AndroWordToSpan\n MIT license - Bachors");
						dlg.setPositiveButton("OK", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						dlg.create().show();
					}
				});
				Dialog.setNegativeButton("GITHUB", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						jintr.setAction(Intent.ACTION_VIEW);
						jintr.setData(Uri.parse("https://github.com/rinxyzz/StringBuilder"));
						startActivity(jintr);
					}
				});
				Dialog.create().show();
			}
		});
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =MainActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF28282A);
		}
		textview2.setTextIsSelectable(true);
		textview3.setTextIsSelectable(true);
		//STORAGE PERMISSION
	}
	
	public void _SnackBar(final View _base, final String _message, final String _action) {
		com.google.android.material.snackbar.Snackbar _SB = com.google.android.material.snackbar.Snackbar.make(_base, _message, com.google.android.material.snackbar.Snackbar.LENGTH_LONG).setDuration(3000);
		/* MoreBlock from :
Reski Tandi T
reskitch6661@gmail.com */
		_SB.setAction(_action, new View.OnClickListener(){
			@Override
			public void onClick(View v){
				if (true) {
					if (_action.toUpperCase().equals("EXIT")) {
						finish();
					}
					if (_action.equals("Done")) {
						// To do
					}
				}
			}});
		_SB.show();
	}
	
	
	public void _spannableTextview(final TextView _tv, final String _urlColor, final String _usernameColor, final String _hashtagColor, final String _phoneNumberColor, final String _mailColor, final boolean _underline, final String _content) {
		WordToSpan link = new WordToSpan();
		link.setColorTAG(Color.parseColor(_hashtagColor))
			.setColorURL(Color.parseColor(_urlColor))
			.setColorPHONE(Color.parseColor(_phoneNumberColor))
			.setColorMAIL(Color.parseColor(_mailColor))
			.setColorMENTION(Color.parseColor(_usernameColor))
			.setUnderlineURL(_underline)
			.setLink(_content)
		  .into(_tv)
		  .setClickListener(new WordToSpan.ClickListener() {
			 @Override
					public void onClick(String type, String text) {
					// type: "tag", "mail", "url", "phone", "mention" or "custom"
							//Toast.makeText(getApplication(), "Type: " + type + "\nText: " + text, Toast.LENGTH_LONG).show();
				SketchwareUtil.showMessage(getApplicationContext(), "Type: ".concat(type.concat("\nContent: ".concat(text))));
				}
			});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}